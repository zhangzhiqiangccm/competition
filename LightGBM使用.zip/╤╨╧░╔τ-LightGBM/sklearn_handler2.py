import tornado.ioloop
import tornado.web
import json
import joblib

import numpy as np

class MainHandler(tornado.web.RequestHandler):
    def get(self):
        self.write("Hello, world")
        
    def post(self):
        data = self.request.body.decode('utf-8')
        data = json.loads(data)
        text = data['data']
        text_feat = vectorizer.transform([text])
        predict_lbl = clf.predict(text_feat)[0]
        
        msg = {
            'label' : int(predict_lbl),
            'code' : 200,
        }
        self.write(json.dumps(msg))

application = tornado.web.Application([
    (r"/", MainHandler),
])


if __name__ == "__main__":
    vectorizer, clf = joblib.load('data2.pkl')
    
    application.listen(9999)
    tornado.ioloop.IOLoop.instance().start()